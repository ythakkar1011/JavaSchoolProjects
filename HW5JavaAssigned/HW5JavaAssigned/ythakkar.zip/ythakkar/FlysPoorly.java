public class FlysPoorly implements FlyBehavior {
    public void fly( ) {
        System.out.println("flies poorly");
    }
}
