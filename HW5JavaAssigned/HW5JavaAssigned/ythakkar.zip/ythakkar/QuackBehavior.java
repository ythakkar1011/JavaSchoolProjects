public interface QuackBehavior {
   public abstract void quack( );
}
