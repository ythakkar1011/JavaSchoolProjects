public class DoesNotLayEggs implements LaysEggs{
    public void laysEgg( ) {
        System.out.println("Not an egg layer.");
    }
}
