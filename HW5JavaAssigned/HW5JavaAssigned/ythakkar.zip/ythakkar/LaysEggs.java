public interface LaysEggs {
    public abstract void laysEgg();
}
