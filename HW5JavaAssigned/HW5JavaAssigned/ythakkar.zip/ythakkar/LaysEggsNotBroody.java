public class LaysEggsNotBroody implements LaysEggs{
    public void laysEgg( ) {
        System.out.println("Lays eggs and will give them up if fed.");
    }
}