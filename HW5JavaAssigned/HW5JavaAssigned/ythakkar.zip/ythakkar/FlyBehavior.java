public interface FlyBehavior {
   public abstract void fly( );
}
