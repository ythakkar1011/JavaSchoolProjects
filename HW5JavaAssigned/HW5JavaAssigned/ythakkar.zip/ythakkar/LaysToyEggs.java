public class LaysToyEggs implements LaysEggs{
    public void laysEgg( ) {
        System.out.println("Lays toy eggs.");
    }
}
