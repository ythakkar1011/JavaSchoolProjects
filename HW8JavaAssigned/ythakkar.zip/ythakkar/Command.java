public interface Command {
        public abstract void execute( );
        public abstract String identify( );
}
